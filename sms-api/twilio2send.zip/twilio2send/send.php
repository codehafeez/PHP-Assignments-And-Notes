<?php

// Update the path below to your autoload.php,
// see https://getcomposer.org/doc/01-basic-usage.md
require __DIR__ . '/vendor/autoload.php';

use Twilio\Rest\Client;

// Find your Account Sid and Auth Token at twilio.com/console
// DANGER! This is insecure. See http://twil.io/secure
$sid    = "sid";
$token  = "token";
$twilio = new Client($sid, $token);

if(isset($_POST['submit'])) {
	$message = $twilio->messages
                  ->create("receiver_number", // to
                           array(
                               "body" => $_POST['message'],
                               "from" => "+12057842852"
                           )
                  );

	//print($message->sid);
	header("Location: index.php?sent");
}