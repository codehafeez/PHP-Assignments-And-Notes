<?php
require __DIR__ . '/vendor/autoload.php';
use Twilio\Rest\Client;
$sid    = "AC6934bee552b0a65c35abad22a0933ce9";
$token  = "fc30cfd19a0a516e8098393b01a4209c";
$twilio = new Client($sid, $token);
	// $message = $twilio->messages->create("+966558758631", // to
	$message = $twilio->messages->create("+966592045036", // to
		array(
			"body" => "Test Message From Hafeez",
			"from" => "+12565636082"
        )
	);

print($message->sid);

